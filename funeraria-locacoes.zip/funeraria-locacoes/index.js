// importar express
var express = require('express');
// importar o handlebars
const exphbs = require('express-handlebars')
const mysql = require('mysql');
// variável para definir o express
var app = express();
var port = 3000

// configuração handlebars

app.engine('handlebars', exphbs.engine())
app.set('view engine', 'handlebars')


//rotas 
//rota raiz
app.get('/', (req, res) => {
    res.render('home', { layout: false })
})


//rota da seção de cadastro
app.get('/cadastrarNovaLocacao', (req, res) => {
    res.render('cadastrarNovaLocacao', { layout: false })
})


//express url
app.use(
        express.urlencoded({
            extended: true

        })
    )
    //rota para inserir dados
app.post('/exibirTodasLocacoes/insertprod', (req, res) => {
    const cnpj = req.body.cnpj
    const nome = req.body.nome
    const endereco = req.body.endereco
    const localidade = req.body.localidade
    const capacidade = req.body.capacidade

    const sql = `INSERT INTO locacoes (cnpj, nome_locacao, endereco, localidade, capacidade) VALUES ('${cnpj}', '${nome}', '${endereco}', '${localidade}', '${capacidade}')`

    conn.query(sql, function(err) {
        if (err) {
            console.log(err)
        }

        res.redirect('/cadastrarNovaLocacao')
    })
})

//rota de consulta geral
app.get('/exibirTodasLocacoes', (req, res) => {
    const sql = 'SELECT * FROM locacoes'

    conn.query(sql, function(err, data) {
        if (err) {
            console.log(err)
            return
        }

        const listar = data

        console.log(listar)

        res.render('exibirTodasLocacoes', { layout: false, listar })

    })
})

// consulta um registo pelo id (produto.handlebars)
app.get('/exibirTodasLocacoes/:id', (req, res) => {
    const id = req.params.id

    const sql = `SELECT * FROM locacoes WHERE id = ${id}`

    conn.query(sql, function(err, data) {
        if (err) {
            console.log(err)
            return
        }

        const listarProd = data[0]
        res.render('detalheIndividualLocacao', { layout: false, listarProd })

    })
})

//rota do buscar
app.get('/buscandoLocacao', (req, res) => {
    res.render('buscarLocacao', { layout: false })
})

//rota busc para exibir o resultado do buscar
app.post('/buscandoLocacao/', (req, res) => {
    const nome_locacao = req.body.nome
    const sql = `SELECT * FROM locacoes WHERE nome_locacao LIKE "${nome_locacao}%"`

    conn.query(sql, function(err, data) {
        if (err) {
            console.log(err)
            return
        }
        const listarProd = data[0]
        res.render('detalheIndividualLocacao', { layout: false, listarProd })
    })
})


//rota para editar registro - Coleta de dados para edição
app.get('/exibirTodasLocacoes/editLocacoes/:id', (req, res) => {

    const id = req.params.id

    const sql = `SELECT * FROM locacoes where id = ${id}`

    conn.query(sql, function(err, data) {
        if (err) {
            console.log(err)
            return
        }

        const prod = data[0]
        res.render('editLocacoes', { layout: false, prod })

    })
})


//rota de edicao do registro com post
app.post('/exibirTodasLocacoes/updateprod', (req, res) => {

    const id = req.body.id
    const cnpj = req.body.cnpj
    const nome = req.body.nome
    const endereco = req.body.endereco
    const localidade = req.body.localidade
    const capacidade = req.body.capacidade

    const sql = `UPDATE locacoes SET cnpj = '${cnpj}', nome_locacao = '${nome}', endereco = '${endereco}', localidade = '${localidade}', capacidade = '${capacidade}' WHERE id = '${id}'`

    conn.query(sql, function(err) {
        if (err) {
            console.log(err)
            return
        }

        res.redirect('/exibirTodasLocacoes')
    })

})


//rota para deletar um registro
app.get('/exibirTodasLocacoes/remove/:id', (req, res) => {
    const id = req.params.id

    const sql = `DELETE FROM locacoes WHERE id = '${id}'`

    conn.query(sql, function(err) {
        if (err) {
            console.log(err)
            return
        }

        res.redirect('/exibirTodasLocacoes')
    })
})


// conexao banco de dados
const conn = mysql.createConnection({
    host: 'localhost',
    port: '3307',
    user: 'root',
    password: '',
    database: 'funerariadb'

})

conn.connect(function(err) {
    if (err) {
        console.log(err)
    }

    console.log('Conectado com sucesso!')


})

//configurar o servidor

app.listen(port, () => {
    console.log(`App rodando na porta ${port}`)
})